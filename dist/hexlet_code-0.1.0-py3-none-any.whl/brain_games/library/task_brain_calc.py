def show_task():
    print('What is the result of the expression?')
