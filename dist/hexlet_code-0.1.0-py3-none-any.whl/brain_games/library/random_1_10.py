from random import randint


def choice_random_number_1_10():
    number = randint(1, 10)
    return number
