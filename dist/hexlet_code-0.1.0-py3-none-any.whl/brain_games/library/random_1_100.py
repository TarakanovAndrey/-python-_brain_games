from random import randint


def choice_random_number():
    num = randint(1, 100)
    return num
