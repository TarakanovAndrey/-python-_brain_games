def show_task():
    print('Find the greatest common divisor of given numbers.')
