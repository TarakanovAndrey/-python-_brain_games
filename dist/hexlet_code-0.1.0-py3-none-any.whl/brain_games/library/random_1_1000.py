from random import randint


def random_num():
    num = randint(1, 1000)
    return num

