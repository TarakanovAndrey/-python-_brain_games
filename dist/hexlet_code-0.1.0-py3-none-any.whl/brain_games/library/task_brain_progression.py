def show_task():
    print('What number is missing in the progression?')
