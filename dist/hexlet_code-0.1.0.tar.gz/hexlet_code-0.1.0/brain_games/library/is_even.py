def is_even(num):
    if num % 2 == 0:
        return 'yes'
    else:
        return 'no'
