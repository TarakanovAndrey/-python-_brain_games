def show_task():
    print('Answer "yes" if given number is prime. Otherwise answer "no".')
