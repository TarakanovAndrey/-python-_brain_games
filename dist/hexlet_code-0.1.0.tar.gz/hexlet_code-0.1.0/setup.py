# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/TarakanovAndrey/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/TarakanovAndrey/python-project-49/actions)\n\n<a href="https://codeclimate.com/github/TarakanovAndrey/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/fed6fd02e34a6134800b/maintainability" /></a>\n\n# Добро пожаловать в Brain Games!\n## Установка\nДля установки пакета brain-games в терминале введите следующую команду:  \n`git clone git@github.com:TarakanovAndrey/python-project-49.git`  \nИз директории python-project-49 введите команду  \n`make package-install`\n## Описание игр\nТеперь вам доступно пять игр. Все игры работают по схожей логике. Необходимо ввести название игры (указаны ниже). Игра поприветствует вас и попросит ввести свое имя. Далее вы увидите задание. В случае трех верных ответов подряд игра поздравит вас и завершится. В случае неверного ответа, игра завершится и предложит вам начать заново. В этом случае, для возобновления игры необходимо опять ввести ее название.  \n\n**Игра "Проверка на четность"**  \nВведите в терминале команду:  \n`brain-even`  \nСуть игры в следующем: вам показывается случайное число. И нужно ответить yes, если число чётное, или no — если нечётное.  \n\n**Игра "Калькулятор"**  \nВведите в терминале команду:  \n`brain-calc`  \nВам показывается случайное математическое выражение, например 35 + 16, которое нужно вычислить и записать правильный ответ.  \n\n**Игра "НОД"**  \nВведите в терминале команду:  \n`brain-gcd`  \nСуть игры в следующем: вам показывается два случайных числа, например, 25 50. Необходимо вычислить и ввести наибольший общий делитель этих чисел.  \n\n**Игра "Арифметическая прогрессия"**  \nВведите в терминале команду:  \n`brain-progression`  \nСуть игры в следующем: вам показывается ряд чисел, одно из которых пропущено. Необходимо определить это число и ввести его.  \n\n**Игра "Простое ли число"**  \nВведите в терминале команду:  \n`brain-prime`  \nСуть игры в следующем: вам показывается случайное число. И нужно ответить yes, если число простое, или no — если нет. \n',
    'author': 'Andrey_Tarakanov',
    'author_email': 'andrey.t-krd@yandex.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
